Enjoy your SafeGraph data!


NEED SUPPORT?
• Join our community of data enthusiasts to get all of your technical questions answered: https://www.safegraph.com/community/
• Or, reach out to support@safegraph.com if you have any issues with your purchased data.


LEARN MORE ABOUT OUR DATASETS
• Places - business listings data: https://docs.safegraph.com/docs/core-places 
• Geometry - place shapes data: https://docs.safegraph.com/docs/geometry-data 
• Foot Traffic Patterns - consumer foot traffic data aggregated by place: https://docs.safegraph.com/docs/monthly-patterns


WE HAVE AN API TOO!
• Want use our API to programmatically request data? https://safegraph.dev/


1 YEAR DATA LICENSE
• Your data is licensed for 1-year from purchase. https://shop.safegraph.com/terms-of-service/ 
